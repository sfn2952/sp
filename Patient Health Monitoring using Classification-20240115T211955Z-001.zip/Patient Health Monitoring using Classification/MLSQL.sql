CREATE OR REPLACE SNOWFLAKE.ML.ANOMALY_DETECTION anomaly_heartrate(
  INPUT_DATA =>
    SYSTEM$QUERY_REFERENCE(
      'SELECT to_timestamp_ntz(TIMESTAMP) as timestamp,personid, age, gender, heartrate, workingout, occupation, healthcondition, to_boolean(anomalylabel) as anomalylabel  FROM heartrate_data where TIMESTAMP < \'2023-10-15 15:00:00\' '
    ),
SERIES_COLNAME => 'PERSONID',
TIMESTAMP_COLNAME => 'TIMESTAMP',
TARGET_COLNAME => 'HEARTRATE',
LABEL_COLNAME => 'ANOMALYLABEL');


CALL anomaly_heartrate!DETECT_ANOMALIES(
   INPUT_DATA =>
    SYSTEM$QUERY_REFERENCE(
      'SELECT to_timestamp_ntz(TIMESTAMP) as timestamp,personid, age, gender, heartrate, workingout, occupation, healthcondition  FROM heartrate_data where TIMESTAMP > \'2023-10-15 15:00:00\' '
    ),
SERIES_COLNAME => 'PERSONID',
TIMESTAMP_COLNAME => 'TIMESTAMP',
TARGET_COLNAME => 'HEARTRATE');

