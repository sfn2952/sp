import snowflake.snowpark as snowpark
from snowflake.snowpark.functions import col
from pycaret.classification import setup, create_model, load_model, plot_model, predict_model
import os
import sys
import pandas as pd

def main(session: snowpark.Session):
    # Your code goes here, inside the "main" handler.
    
    import_dir = sys._xoptions.get("snowflake_import_directory")
    trained_model = load_model(os.path.join(import_dir, 'anomaly_pycaret_'+str(1)))

    data_df_input = session.sql("select age, gender,timestamp, heartrate, workingout, occupation, healthcondition from ML_DB.ML_SCHEMA.HEARTRATE_DATA where timestamp > '15-10-2023 18:00:00' " )
    data_df_input = data_df_input.to_pandas()
    data_df = data_df_input.rename(columns={
    0: "AGE",
    1: "GENDER",
    2: "TIMESTAMP",
    3: "HEARTRATE",
    4: "WORKINGOUT",
    5: "OCCUPATION",
    6: "HEALTHCONDITION"
    })


    predictions = predict_model(trained_model, data=data_df, raw_score=True)

    # Return value will appear in the Results tab.
    return predictions['prediction_score_1'].tolist();