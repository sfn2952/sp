create or replace function inference_model(personid int, age int, gender string,timestamp string, heartrate float, workingout string, occupation string, healthcondition string)
    returns Variant
    language python
    runtime_version = 3.8
    packages =('pycaret==3.0.2', 'snowflake-snowpark-python==*') imports =(
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_10/anomaly_pycaret_10.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_9/anomaly_pycaret_9.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_8/anomaly_pycaret_8.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_7/anomaly_pycaret_7.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_6/anomaly_pycaret_6.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_5/anomaly_pycaret_5.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_4/anomaly_pycaret_4.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_3/anomaly_pycaret_3.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_2/anomaly_pycaret_2.pkl',
        '@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_1/anomaly_pycaret_1.pkl'
    )
    handler = 'main'
    as 'import snowflake.snowpark as snowpark
from snowflake.snowpark.functions import col
from pycaret.classification import setup, create_model, load_model, plot_model, predict_model
import os
import sys
import pandas as pd

from _snowflake import vectorized
@vectorized(input=pd.DataFrame, max_batch_size=1000)
def main(data_df_input: pd.DataFrame):
    # Your code goes here, inside the "main" handler.
    
    import_dir = sys._xoptions.get("snowflake_import_directory")
   
    data_df_input = data_df_input.to_pandas()
    data_df = data_df_input.rename(columns={
    0: "PERSONID",
    1: "AGE",
    2: "GENDER",
    3: "TIMESTAMP",
    4: "HEARTRATE",
    5: "WORKINGOUT",
    6: "OCCUPATION",
    7: "HEALTHCONDITION"
    })

    person_id = data_df["PERSONID"].unique()[0]

    data_df_filtered = data_df.drop("PERSONID", axis = 1)

    trained_model = load_model(os.path.join(import_dir, "anomaly_pycaret_"+str(person_id)))

    predictions = predict_model(trained_model, data=data_df_filtered, raw_score=True)

    # Return value will appear in the Results tab.
    return predictions[''prediction_score_1''].tolist();';

    select heartrate, ml_db.ml_schema.anomaly_inference(personid, age, gender,timestamp, heartrate, workingout, occupation, healthcondition) as probabilty_score from ml_db.ml_schema.HEARTRATE_DATA where personid=6 and TIMESTAMP > '2023-10-15 13:00:00'