import snowflake.snowpark as snowpark
import os
import sys
from pycaret.classification import setup, create_model, save_model, interpret_model, finalize_model,get_metrics, pull
import pandas as pd

def main(session: snowpark.Session): 

    import_dir = sys._xoptions.get("snowflake_import_directory")
    dataframe = session.table('ml_db.ml_schema.HEARTRATE_DATA')
    df_pandas = dataframe.to_pandas()
    person_ids = df_pandas['PERSONID'].unique()

    for p in person_ids:

        df_pandas_filtered = df_pandas[df_pandas['PERSONID'] == p].drop('PERSONID', axis=1)
        
        s = setup(df_pandas_filtered, session_id = 123, normalize= True, target='ANOMALYLABEL', fold_strategy='timeseries')
        
        model = create_model('rf')
    
        final_model = finalize_model(model)
        
        save_model(final_model, os.path.join(import_dir, '/tmp/anomaly_pycaret'))
    
        session.file.put(
            os.path.join(import_dir, '/tmp/anomaly_pycaret.pkl'),
            "@ml_stage/model_"+str(p),
            auto_compress=False,
            overwrite=True
        )
    
        interpret_model(model, save=os.path.join(import_dir, '/tmp'))
    
        session.file.put(
            os.path.join(import_dir, '/tmp/SHAP summary.png'),
            "@ml_stage/model_"+str(p),
            auto_compress=False,
            overwrite=True
        )

    # Return value will appear in the Results tab.
    return 'Model Trained Successfully'