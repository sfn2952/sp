create or replace procedure train_model("training_table" varchar)
    returns String
    language python
    runtime_version = 3.8
    packages =(
        'pycaret==3.0.2',
        'shap==0.42.1',
        'snowflake-snowpark-python==*'
    )
    handler = 'main'
    as 'import snowflake.snowpark as snowpark
import os
import sys
from pycaret.classification import setup, create_model, save_model, interpret_model, finalize_model,get_metrics, pull
import pandas as pd

def main(session: snowpark.Session, training_table: str): 

    import_dir = sys._xoptions.get("snowflake_import_directory")
    dataframe = session.table(training_table)
    df_pandas = dataframe.to_pandas()
    person_ids = df_pandas[''PERSONID''].unique()

    for p in person_ids:

        df_pandas_filtered = df_pandas[df_pandas[''PERSONID''] == p].drop(''PERSONID'', axis=1)
        
        s = setup(df_pandas_filtered, session_id = 123, normalize= True, target=''ANOMALYLABEL'', fold_strategy=''timeseries'')
        
        model = create_model(''rf'')
    
        final_model = finalize_model(model)
        
        save_model(final_model, os.path.join(import_dir, ''/tmp/anomaly_pycaret_''+str(p)))
    
        session.file.put(
            os.path.join(import_dir, ''/tmp/anomaly_pycaret_''+str(p)+''.pkl''),
            "@ml_stage/model_"+str(p),
            auto_compress=False,
            overwrite=True
        )
    
        interpret_model(model, save=os.path.join(import_dir, ''/tmp''))
    
        session.file.put(
            os.path.join(import_dir, ''/tmp/SHAP summary.png''),
            "@ml_stage/model_"+str(p),
            auto_compress=False,
            overwrite=True
        )

    # Return value will appear in the Results tab.
    return ''Model Trained Successfully''';

    CALL train_model('ML_DB.ML_SCHEMA.HEARTRATE_DATA')