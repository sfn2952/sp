# Import python packages
import streamlit as st
from snowflake.snowpark.context import get_active_session
import pandas as pd 
import numpy as np 
from scipy import stats
import matplotlib.pyplot as plt 
import plotly.express as px
import matplotlib
import seaborn as sns
import statsmodels.api as sm 
import shap
import os
import sys
import json
import lime
import lime.lime_tabular
import streamlit.components.v1 as components
from snowflake.snowpark.functions import call_udf,col
from pycaret.classification import setup, create_model, save_model, interpret_model, load_model, predict_model


#image = Image.open('cover.jpg')
matplotlib.use("Agg")

st.set_option('deprecation.showPyplotGlobalUse', False)



class EDA_Dataframe_Analysis():
	def __init__(self):
		print("General_EDA object created")

	def show_dtypes(self,x):
		return x.dtypes


	def show_columns(self,x):
		return x.columns


	def Show_Missing(self,x):
		return x.isna().sum()


	def Show_Missing1(self,x):
		return x.isna().sum()


	def Show_Missing2(self,x):
		return x.isna().sum()


	def show_hist(self,x):
		fig = plt.figure(figsize = (15,20))
		ax = fig.gca()
		return x.hist(ax=ax)


	def Tabulation(self,x):
		table = pd.DataFrame(x.dtypes,columns=['dtypes'])
		table1 =pd.DataFrame(x.columns,columns=['Names'])
		table = table.reset_index()
		table= table.rename(columns={'index':'Name'})
		table['No of Missing'] = x.isnull().sum().values    
		table['No of Uniques'] = x.nunique().values
		table['Percent of Missing'] = ((x.isnull().sum().values)/ (x.shape[0])) *100
		table['First Observation'] = x.loc[0].values
		table['Second Observation'] = x.loc[1].values
		table['Third Observation'] = x.loc[2].values
		for name in table['Name'].value_counts().index:
			table.loc[table['Name'] == name, 'Entropy'] = round(stats.entropy(x[name].value_counts(normalize=True), base=2),2)
		return table


	def Numerical_variables(self,x):
		Num_var = [var for var in x.columns if x[var].dtypes!="object"]
		Num_var = x[Num_var]
		return Num_var

	def categorical_variables(self,x):
		cat_var = [var for var in x.columns if x[var].dtypes=="object"]
		cat_var = x[cat_var]
		return cat_var


	def plotly(self,a,x,y):
		fig = px.scatter(a, x=x, y=y)
		fig.update_traces(marker=dict(size=10,
										line=dict(width=2,
												color='DarkSlateGrey')),
							selector=dict(mode='markers'))
		fig.show()

	def show_displot(self,x):
			plt.figure(1)
			plt.subplot(121)
			sns.distplot(x)


			plt.subplot(122)
			x.plot.box(figsize=(16,5))

			plt.show()

	def Show_DisPlot(self,x):
		plt.style.use('fivethirtyeight')
		plt.figure(figsize=(12,7))
		return sns.distplot(x, bins = 25)

	def Show_CountPlot(self,x):
		fig_dims = (18, 8)
		fig, ax = plt.subplots(figsize=fig_dims)
		return sns.countplot(x,ax=ax)

	def plotly_histogram(self,a,x,y):
		fig = px.histogram(a, x=x, y=y)
		fig.update_traces(marker=dict(size=10,
										line=dict(width=2,
												color='DarkSlateGrey')),
							selector=dict(mode='markers'))
		fig.show()


	def plotly_violin(self,a,x,y):
		fig = px.histogram(a, x=x, y=y)
		fig.update_traces(marker=dict(size=10,
										line=dict(width=2,
												color='DarkSlateGrey')),
							selector=dict(mode='markers'))
		fig.show()

	def Show_PairPlot(self,x):
		return sns.pairplot(x)

	def Show_HeatMap(self,x):
		f,ax = plt.subplots(figsize=(15, 15))
		x = self.Numerical_variables(x)
		return sns.heatmap(x.corr(),annot=True,ax=ax);


	def label(self,x):
		from sklearn.preprocessing import LabelEncoder
		le = LabelEncoder()
		x=le.fit_transform(x)
		return x

	def label1(self,x):
		from sklearn.preprocessing import LabelEncoder
		le = LabelEncoder()
		x=le.fit_transform(x)
		return x

	def concat(self,x,y,z,axis):
		return pd.concat([x,y,z],axis)

	def dummy(self,x):
		return pd.get_dummies(x)


	def qqplot(self,x):
		return sm.qqplot(x, line ='45')


	def Anderson_test(self,a):
		return anderson(a)

	def PCA(self,x):
		pca =PCA(n_components=8)
		principlecomponents = pca.fit_transform(x)
		principledf = pd.DataFrame(data = principlecomponents)
		return principledf

	def outlier(self,x):
		high=0
		q1 = x.quantile(.25)
		q3 = x.quantile(.75)
		iqr = q3-q1
		low = q1-1.5*iqr
		high += q3+1.5*iqr
		outlier = (x.loc[(x < low) | (x > high)])
		return(outlier)


class Attribute_Information():

    def __init__(self):
        
        print("Attribute Information object created")
        
    def Column_information(self,data):
    
        data_info = pd.DataFrame(
                                columns=['No of observation',
                                        'No of Variables',
                                        'No of Numerical Variables',
                                        'No of Factor Variables',
                                        'No of Categorical Variables',
                                        'No of Logical Variables',
                                        'No of Date Variables',
                                        'No of zero variance variables'])


        data_info.loc[0,'No of observation'] = data.shape[0]
        data_info.loc[0,'No of Variables'] = data.shape[1]
        data_info.loc[0,'No of Numerical Variables'] = data._get_numeric_data().shape[1]
        data_info.loc[0,'No of Factor Variables'] = data.select_dtypes(include='category').shape[1]
        data_info.loc[0,'No of Logical Variables'] = data.select_dtypes(include='bool').shape[1]
        data_info.loc[0,'No of Categorical Variables'] = data.select_dtypes(include='object').shape[1]
        data_info.loc[0,'No of Date Variables'] = data.select_dtypes(include='datetime64').shape[1]
        data_info.loc[0,'No of zero variance variables'] = data.loc[:,data.apply(pd.Series.nunique)==1].shape[1]

        data_info =data_info.transpose()
        data_info.columns=['value']
        data_info['value'] = data_info['value'].astype(int)


        return data_info
    
    def __get_missing_values(self,data):
        
        #Getting sum of missing values for each feature
        missing_values = data.isnull().sum()
        #Feature missing values are sorted from few to many
        missing_values.sort_values(ascending=False, inplace=True)
        
        #Returning missing values
        return missing_values

        
    def __iqr(self,x):
        return x.quantile(q=0.75) - x.quantile(q=0.25)

    def __outlier_count(self,x):
        upper_out = x.quantile(q=0.75) + 1.5 * self.__iqr(x)
        lower_out = x.quantile(q=0.25) - 1.5 * self.__iqr(x)
        return len(x[x > upper_out]) + len(x[x < lower_out])

    def num_count_summary(self,df):
        df_num = df._get_numeric_data()
        data_info_num = pd.DataFrame()
        i=0
        for c in  df_num.columns:
            data_info_num.loc[c,'Negative values count']= df_num[df_num[c]<0].shape[0]
            data_info_num.loc[c,'Positive values count']= df_num[df_num[c]>0].shape[0]
            data_info_num.loc[c,'Zero count']= df_num[df_num[c]==0].shape[0]
            data_info_num.loc[c,'Unique count']= len(df_num[c].unique())
            data_info_num.loc[c,'Negative Infinity count']= df_num[df_num[c]== -np.inf].shape[0]
            data_info_num.loc[c,'Positive Infinity count']= df_num[df_num[c]== np.inf].shape[0]
            data_info_num.loc[c,'Missing Percentage']= df_num[df_num[c].isnull()].shape[0]/ df_num.shape[0]
            data_info_num.loc[c,'Count of outliers']= self.__outlier_count(df_num[c])
            i = i+1
        return data_info_num
    
    def statistical_summary(self,df):
    
        df_num = df._get_numeric_data()

        data_stat_num = pd.DataFrame()

        try:
            data_stat_num = pd.concat([df_num.describe().transpose(),
                                       pd.DataFrame(df_num.quantile(q=0.10)),
                                       pd.DataFrame(df_num.quantile(q=0.90)),
                                       pd.DataFrame(df_num.quantile(q=0.95))],axis=1)
            data_stat_num.columns = ['count','mean','std','min','25%','50%','75%','max','10%','90%','95%']
        except:
            pass

        return data_stat_num



class Charts():

    def __init__(self):
        print("Charts object created")
    
    def scatter_plot(self,df,X,Y, Color=None):
        fig = px.scatter(df, y = Y, x=X,orientation='h', color=Color, render_mode='svg')
        fig.update_layout(title={'text':f"{X} vs {Y}", 'x': 0.5, 'y':0.95}, margin= dict(l=0,r=10,b=10,t=30), yaxis_title=Y, xaxis_title=X)
        st.plotly_chart(fig, use_container_width=True)

    def box_plot(self,df,X,Y):
        fig = px.box(df, y = Y, x=X)
        fig.update_layout(title={'text':f"{X} vs {Y}", 'x': 0.5, 'y':0.95}, margin= dict(l=0,r=10,b=10,t=30), yaxis_title=Y, xaxis_title=X)
        st.plotly_chart(fig, use_container_width=True)


    def bar_plot(self,df, X, Color):
        fig = px.bar(df, x=X, color=Color)
        fig.update_layout(title={'text':f"{X} vs {Color}", 'x': 0.5, 'y':0.95}, margin= dict(l=0,r=10,b=10,t=30), yaxis_title=Color, xaxis_title=X)
        st.plotly_chart(fig, use_container_width=True)


    def plotly_violin(self,df,Y):
        fig = px.violin(df, y=Y)
        fig.update_traces(marker=dict(size=10,
                          line=dict(width=2,
                          color='DarkSlateGrey')),
                          selector=dict(mode='markers'))
        st.plotly_chart(fig, use_container_width=True)


 

def main():
	st.title("Anomaly Detection on Heartrate Data")
	tabs = st.tabs(['EDA', 'Inference', 'Bulk Inference'])
	st.info(" Streamlit Web Application ") 

	def create_table_config(df):
		table_config = {}
		for column in df.columns:
			table_config[column] = str(column)

		return table_config
			


	with tabs[0]:
		st.subheader("Exploratory Data Analysis")

        
    
		tableName = 'ML_DB.ML_SCHEMA.HEARTRATE_DATA'
    
		data = session.table(tableName)
		df = data.to_pandas()
		columns = df.columns

		table_config = create_table_config(df)  


		
		if data is not None:
			
			st.dataframe(df.head())
			st.success("Data Frame Loaded successfully")

			st.subheader("UNIVARIATE ANALYSIS")

			if st.checkbox("Show dtypes"):
				st.write(dataframe.show_dtypes(df))

			if st.checkbox("Show Columns"):
				st.write(dataframe.show_columns(df))

			if st.checkbox("Show Missing"):
				st.write(dataframe.Show_Missing1(df))

			if st.checkbox("column information"):
				st.write(info.Column_information(df))

			if st.checkbox("Aggregation Tabulation"):
				st.write(dataframe.Tabulation(df))

			if st.checkbox("Num Count Summary"):
				st.write(info.num_count_summary(df))

			if st.checkbox("Statistical Summary"):
				st.write(info.statistical_summary(df))		

			if st.checkbox("Numerical Variables"):
				num_df = dataframe.Numerical_variables(df)
				numer_df=pd.DataFrame(num_df)                
				st.dataframe(numer_df)

			if st.checkbox("Categorical Variables"):
				new_df = dataframe.categorical_variables(df)
				catego_df=pd.DataFrame(new_df)                
				st.dataframe(catego_df)

			if st.checkbox("Show Histogram"):
				dataframe.show_hist(df)
				st.pyplot()

			st.subheader("BIVARIATE ANALYSIS")

			x_column = st.selectbox( "Select X column", columns, index = 3, key=11)
			y_column = st.selectbox("Select Y column" , columns, index = 4, key=22)
			plot_charts.scatter_plot(df=df[:5759],X='TIMESTAMP',Y='HEARTRATE',Color='ANOMALYLABEL')

			x_column = st.selectbox( "Select X column", columns, index = 2, key=1)
			y_column = st.selectbox("Select Y column" , columns, index = 4, key=2)
			plot_charts.box_plot(df=df,X=x_column,Y=y_column)

			x_column = st.selectbox("Select X column", columns, index = 5, key=3)
			y_column = st.selectbox("Select Y column" , columns, index = 4, key=4)
			plot_charts.box_plot(df=df,X=x_column,Y=y_column)

			x_column = st.selectbox("Select X column", columns, index = 2, key=5)
			color_column = st.selectbox("Select Color column" , columns, index = 5, key=6)
			plot_charts.bar_plot(df=df,X=x_column,Color=color_column)
			
			x_column = st.selectbox("Select X column", columns, index = 2, key=7)
			color_column = st.selectbox("Select Color column" , columns, index = 7, key=8)
			plot_charts.bar_plot(df=df,X=x_column,Color=color_column)


			if st.checkbox("Show HeatMap"):
				dataframe.Show_HeatMap(df)
				st.pyplot()

			if st.checkbox("Show PairPlot"):
				dataframe.Show_PairPlot(df)
				st.pyplot()
	
	with tabs[1]:
	
		personid_options =  [1,2,3,4,5,6,7,8,9,10]
		age_options = df['AGE'].unique().tolist()
		gender_options = df['GENDER'].unique().tolist()
		workingout_options = df['WORKINGOUT'].unique().tolist()
		occupation_options = df['OCCUPATION'].unique().tolist()
		health_condition_options = df['HEALTHCONDITION'].unique().tolist()
		heartrate_options = df['HEARTRATE'].unique().tolist()

		
		# Streamlit app
		st.title('Data Entry Form')
		# Dropdowns for categorical values
		personid = st.selectbox('Select Person ID', personid_options)
		gender = st.selectbox('Select Gender', gender_options)
		# Dropdown for timestamp with 30-second intervals
		timestamp_options = pd.to_datetime(df['TIMESTAMP']).dt.strftime('%Y-%m-%d %H:%M:%S').tolist()
		timestamp = st.selectbox('Select Timestamp', timestamp_options)
		workingout = st.selectbox('Select Working Out', workingout_options)
		occupation = st.selectbox('Select Occupation', occupation_options)
		healthcondition = st.selectbox('Select Health Condition', health_condition_options)
		# Slider for numerical value
		age = st.slider('Select Age', min_value=int(sorted(age_options)[0]), max_value=int(sorted(age_options, reverse=True)[1]))
		heartrate = st.slider('Select Heartrate', min_value=int(sorted(heartrate_options)[0]), max_value=int(sorted(heartrate_options, reverse=True)[1]))


		if st.button("Predict"):
			prediction = session.sql(f"select ML_DB.ML_SCHEMA.ANOMALY_INFERENCE({personid},{age}, '{gender}', '{timestamp}', '{heartrate}', '{workingout}', '{occupation}', '{healthcondition}') as PROBABILITY_SCORE")


			session.file.get('@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_'+str(personid)+'/anomaly_pycaret_'+str(personid)+'.pkl','/tmp')
			loaded_model = load_model('/tmp/anomaly_pycaret_'+str(personid))


			df = session.table('ML_DB.ML_SCHEMA.HEARTRATE_DATA').to_pandas()
			
			Y = df["ANOMALYLABEL"]
			X = loaded_model[:-1].transform(df).drop(columns=["ANOMALYLABEL","PERSONID"], axis=1)
			X_featurenames = X.columns.tolist()

			# st.write(X.head(1))
			
			explainer = lime.lime_tabular.LimeTabularExplainer(X.values,
								feature_names=X_featurenames, 
								class_names=['ANOMALY','NON-ANOMALY'],
								discretize_continuous = True,
								verbose=True, mode='classification')

			instance_to_predict = loaded_model[:-1].transform(pd.DataFrame({'AGE':[age], 'GENDER':[gender], 'TIMESTAMP':[timestamp],'HEARTRATE':[heartrate], 'WORKINGOUT':[workingout], 'OCCUPATION':[occupation], 'HEALTHCONDITION':[healthcondition]}))

			exp = explainer.explain_instance(instance_to_predict.values.flatten(), loaded_model.named_steps["actual_estimator"].predict_proba, top_labels=2)
		
			# exp.save_to_file('/tmp/lime_exp.html')

			# session.file.put(
			# 		'/tmp/lime_exp.html',
			# 		"@DATA_SCIENCE_MODELS",
			# 		auto_compress=False,
			# 		overwrite=True
			# 	)

			# train_pipe = loaded_model[:-1].transform(df)

			# explainer = shap.TreeExplainer(loaded_model.named_steps["actual_estimator"], train_pipe)
			# shap_values = explainer.shap_values(train_pipe, Y,check_additivity=False)


			# shap.summary_plot(shap_values, train_pipe)


			score = prediction.to_pandas()['PROBABILITY_SCORE'].values[0]*100

			if prediction.to_pandas()['PROBABILITY_SCORE'].values[0]*100 > 50:
				st.subheader(f"The probability of a heartcondition for the given heartrate is :red[{score}] percent")
			else:
				st.subheader(f"The probability of a heartcondition for the given heartrate is :green[{score}] percent")


			st.subheader('Local Explanability')
			exp.as_pyplot_figure(label=0)
			st.pyplot()

			session.file.get('@"ML_DB"."ML_SCHEMA"."ML_STAGE"/model_'+str(personid)+'/SHAP summary.png','/tmp')
			st.subheader('Global Explanability')
			st.image('/tmp/SHAP summary.png')



	with tabs[2]:

		personid_options =  [1,2,3,4,5,6,7,8,9,10]
		option = st.selectbox('Select Person Id', personid_options)

		if option is not None:
			
			# filtered_data = session.sql(f"select * from heartrate_data where personid = {option}")
			# filtered_data_df = filtered_data.to_pandas()
			predictions = session.sql(f"select timestamp, heartrate, ML_DB.ML_SCHEMA.ANOMALY_INFERENCE(personid, age, gender,timestamp, heartrate, workingout, occupation, healthcondition) as heartcondition_probability from ML_DB.ML_SCHEMA.HEARTRATE_DATA where personid = {option}")
			st.write(predictions)
			predictions_pandas = predictions.to_pandas()
			plt.figure(figsize=(8,6))
			plot_charts.scatter_plot(df=predictions_pandas, X='TIMESTAMP',Y='HEARTRATE', Color='HEARTCONDITION_PROBABILITY')



if __name__ == '__main__':
    dataframe = EDA_Dataframe_Analysis()
    info = Attribute_Information()
    session = get_active_session()
    plot_charts = Charts()
    main()
